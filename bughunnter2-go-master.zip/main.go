package main

import "github.com/SirYadav1/bughunnter2-go/cmd"

func main() {
	cmd.Execute()
}
